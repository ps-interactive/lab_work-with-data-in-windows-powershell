const express = require('express');
const fs = require('fs');
const app = express();

const FEEDBACK_FILE = 'feedback.txt';

app.use(express.json());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Allows all domains
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});


function readFeedbackFromFile() {
    if (fs.existsSync(FEEDBACK_FILE)) {
        const fileContent = fs.readFileSync(FEEDBACK_FILE, 'utf8');
        return JSON.parse(fileContent);
    }
    return [];
}

function writeFeedbackToFile(feedbackData) {
    fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(feedbackData, null, 2), 'utf8');
}

app.put('/feedback/:id', (req, res) => {
    const id = parseInt(req.params.id); // Convert ID from URL to integer
    const feedbackData = readFeedbackFromFile(); // Read all feedback from file
    const feedbackIndex = feedbackData.findIndex(f => f.id === id); // Find the index of the feedback by ID

    if (feedbackIndex !== -1) {
        // Update the feedback at the found index
        feedbackData[feedbackIndex] = {
            ...feedbackData[feedbackIndex],
            ...req.body // Assumes the body contains updated fields
        };

        writeFeedbackToFile(feedbackData); // Write the updated array back to the file
        res.json(feedbackData[feedbackIndex]); // Respond with the updated feedback
    } else {
        res.status(404).json({ message: 'Feedback not found' }); // If not found, send a 404 response
    }
});


app.get('/feedback/:id', (req, res) => {
    const id = parseInt(req.params.id); // Extract the ID from the URL and convert to integer
    const feedbackData = readFeedbackFromFile(); // Read all feedback
    const feedback = feedbackData.find(f => f.id === id); // Find the specific feedback by ID

    if (feedback) {
        res.json(feedback);
    } else {
        res.status(404).json({ message: 'Feedback not found' }); // If not found, send a 404 response
    }
});

app.post('/feedback', (req, res) => {
    const newFeedback = req.body;
    if (!newFeedback.id) {
        return res.status(400).json({ message: 'Feedback must include an id' });
    }

    const feedbackData = readFeedbackFromFile();
    const exists = feedbackData.some(f => f.id === newFeedback.id);
    if (exists) {
        return res.status(409).json({ message: 'Feedback with this ID already exists' });
    }

    feedbackData.push(newFeedback);
    writeFeedbackToFile(feedbackData);
    res.status(201).json(newFeedback);
});


app.get('/api/feedback', (req, res) => {
    const feedbackData = readFeedbackFromFile();
    res.json(feedbackData);
});

app.use('/public', express.static('public'));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running`);
});